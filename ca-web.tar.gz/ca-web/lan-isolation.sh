#!/usr/bin/env bash
# Aisla los contenedores de ca-web de tu red local.
#
#   - Internet: abierto (el instalador de contenido y el multiplayer lo necesitan).
#   - Redes privadas (10/8, 172.16/12, 192.168/16, CGNAT 100.64/10, link-local,
#     multicast...): bloqueadas, salvo los servidores de CA_ALLOW_SERVERS.
#   - El propio LXC: los contenedores no pueden iniciar conexiones hacia el.
#
# Uso:  ./lan-isolation.sh [apply|remove|status]     (como root, dentro del LXC)
# Lee CA_ALLOW_SERVERS ("ip:puerto,ip:puerto") del .env que esta al lado del script,
# o de la variable de entorno del mismo nombre.
#
# Es idempotente: apply parte siempre de cero. Las reglas no sobreviven a un
# reinicio; por eso existe ca-web-isolation.service.

set -euo pipefail

ACTION="${1:-apply}"
HERE="$(cd "$(dirname "$(readlink -f "$0")")" && pwd)"
ENVFILE="${CA_ENVFILE:-$HERE/.env}"
BRIDGE="${CA_BRIDGE:-br-ca}"
FWD_CHAIN="CA-WEB-FWD"
IN_CHAIN="CA-WEB-IN"

ipt() { iptables -w 5 "$@"; }

envval() {
  [ -f "$ENVFILE" ] || return 0
  { grep -E "^$1=" "$ENVFILE" || true; } | tail -n 1 | cut -d= -f2- \
    | sed -E 's/[[:space:]]+#.*$//; s/^"//; s/"$//'
}

remove() {
  while ipt -C DOCKER-USER -i "$BRIDGE" -j "$FWD_CHAIN" 2>/dev/null; do
    ipt -D DOCKER-USER -i "$BRIDGE" -j "$FWD_CHAIN"
  done
  while ipt -C INPUT -i "$BRIDGE" -j "$IN_CHAIN" 2>/dev/null; do
    ipt -D INPUT -i "$BRIDGE" -j "$IN_CHAIN"
  done
  for c in "$FWD_CHAIN" "$IN_CHAIN"; do
    ipt -F "$c" 2>/dev/null || true
    ipt -X "$c" 2>/dev/null || true
  done
}

apply() {
  if ! ipt -S DOCKER-USER >/dev/null 2>&1; then
    echo "No existe la cadena DOCKER-USER: Docker tiene que estar corriendo." >&2
    exit 1
  fi

  local allow="${CA_ALLOW_SERVERS:-$(envval CA_ALLOW_SERVERS)}"
  local servers=() entry ip port net

  # Se valida todo antes de tocar el firewall.
  IFS=',' read -r -a servers <<< "$allow"
  for entry in "${servers[@]}"; do
    entry="${entry// /}"
    [ -z "$entry" ] && continue
    ip="${entry%:*}"; port="${entry##*:}"
    if ! [[ "$ip" =~ ^[0-9]{1,3}(\.[0-9]{1,3}){3}$ && "$port" =~ ^[0-9]{1,5}$ ]]; then
      echo "CA_ALLOW_SERVERS: entrada invalida '$entry' (usa ip:puerto)." >&2
      exit 1
    fi
  done

  remove

  # --- Trafico que los contenedores mandan hacia afuera (cadena FORWARD) ---
  ipt -N "$FWD_CHAIN"
  ipt -A "$FWD_CHAIN" -m conntrack --ctstate ESTABLISHED,RELATED -j RETURN
  for entry in "${servers[@]}"; do
    entry="${entry// /}"
    [ -z "$entry" ] && continue
    ip="${entry%:*}"; port="${entry##*:}"
    ipt -A "$FWD_CHAIN" -d "$ip" -p tcp --dport "$port" -j RETURN
  done
  for net in 10.0.0.0/8 172.16.0.0/12 192.168.0.0/16 100.64.0.0/10 169.254.0.0/16 \
             192.0.0.0/24 198.18.0.0/15 224.0.0.0/4 240.0.0.0/4; do
    ipt -A "$FWD_CHAIN" -d "$net" -j DROP
  done
  ipt -A "$FWD_CHAIN" -j RETURN
  ipt -I DOCKER-USER 1 -i "$BRIDGE" -j "$FWD_CHAIN"

  # --- Trafico de los contenedores hacia el propio LXC (cadena INPUT) ---
  ipt -N "$IN_CHAIN"
  ipt -A "$IN_CHAIN" -m conntrack --ctstate ESTABLISHED,RELATED -j ACCEPT
  ipt -A "$IN_CHAIN" -j DROP
  ipt -I INPUT 1 -i "$BRIDGE" -j "$IN_CHAIN"

  echo "Aislamiento aplicado sobre $BRIDGE (servidores permitidos: ${allow:-ninguno})."
}

status() {
  ipt -S DOCKER-USER | grep -E "$FWD_CHAIN" || echo "DOCKER-USER: sin enganche (aislamiento NO aplicado)"
  ipt -S INPUT | grep -E "$IN_CHAIN" || echo "INPUT: sin enganche (aislamiento NO aplicado)"
  ipt -L "$FWD_CHAIN" -n -v 2>/dev/null || true
  ipt -L "$IN_CHAIN" -n -v 2>/dev/null || true
}

case "$ACTION" in
  apply)  apply ;;
  remove) remove; echo "Aislamiento quitado." ;;
  status) status ;;
  *) echo "Uso: $0 [apply|remove|status]" >&2; exit 2 ;;
esac
