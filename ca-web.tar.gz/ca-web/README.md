# Combined Arms en el navegador

Cada jugador abre una URL, entra con su usuario y clave, y juega Combined Arms 1.09
(mod de OpenRA) desde el navegador. El cliente corre dentro de un contenedor con
KasmVNC (imagen base de LinuxServer) y se transmite por HTTPS. Un contenedor por
jugador: cada uno con su usuario, su puerto y su volumen.

| Archivo | Para qué |
|---|---|
| `Dockerfile` | Imagen: base KasmVNC + AppImage oficial verificado por SHA-256 + endurecimiento |
| `docker-compose.yml` | 3 jugadores, límites de recursos, sin comunicación entre ellos |
| `.env.example` | Usuarios, claves, IP, límites, versión |
| `lan-isolation.sh` + `ca-web-isolation.service` | Bloquean el acceso a tu LAN; Internet queda abierto |
| `root/` | Lanzador del juego y menú vacío (se copian dentro de la imagen) |

## Consumo (leer antes de dimensionar)

Sin GPU el juego se dibuja por software (llvmpipe), y eso gasta CPU de verdad.
Medido en el menú, a 1280x720, solo el proceso del juego (sin KasmVNC ni la
codificación de video), en un equipo de 2 núcleos:

| Configuración | CPU |
|---|---|
| De fábrica | 186 % de un core |
| Límite de 30 fps | 84 % |
| 30 fps + 1 hilo de llvmpipe | 78 % |

La imagen arranca con 30 fps. **En partida va a ser más y no lo medí** (no tenía
el contenido del juego). Como punto de partida, contá 2 núcleos por jugador que
juegue a la vez. Con GPU Intel/AMD pasada al LXC debería bajar mucho, pero tampoco
lo medí.

## 1. LXC en Proxmox

Ajustá el nombre de la plantilla (`pveam list local`), el ID, la IP y el storage:

```bash
pct create 210 local:vztmpl/ubuntu-24.04-standard_24.04-2_amd64.tar.zst \
  --hostname ca-web --unprivileged 1 --features nesting=1,keyctl=1 \
  --cores 6 --memory 8192 --swap 0 --rootfs local-lvm:30 \
  --net0 name=eth0,bridge=vmbr0,ip=192.168.1.50/24,gw=192.168.1.1,firewall=1
pct start 210
```

Dentro del LXC instalá Docker Engine y el plugin compose
(<https://docs.docker.com/engine/install/ubuntu/>).

GPU opcional (Intel/AMD), en `/etc/pve/lxc/210.conf`, y después descomentá
`devices:` en el compose. No lo probé; los permisos de `/dev/dri` en un LXC sin
privilegios dependen del mapeo de GID:

```
lxc.cgroup2.devices.allow: c 226:* rwm
lxc.mount.entry: /dev/dri dev/dri none bind,optional,create=dir
```

## 2. Desplegar

```bash
sudo mkdir -p /opt/ca-web && sudo cp -a . /opt/ca-web && cd /opt/ca-web
cp .env.example .env && chmod 600 .env
nano .env                       # BIND_IP, claves (openssl rand -base64 18), CA_ALLOW_SERVERS
docker compose build jugador1   # construye la imagen una sola vez
docker compose up -d
docker compose ps
```

El build falla a propósito si el hash del AppImage no coincide con `CA_SHA256`.

## 3. Aislar los contenedores de tu LAN

Un jugador tiene un escritorio dentro del contenedor. Si alguien explotara el
cliente o el escritorio, sin esto podría llegar a tu red interna.

```bash
sudo chmod +x lan-isolation.sh
sudo cp ca-web-isolation.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now ca-web-isolation
sudo ./lan-isolation.sh status
```

Qué hace: Internet abierto (el instalador de contenido y el multiplayer lo
necesitan); redes privadas bloqueadas salvo los `ip:puerto` de `CA_ALLOW_SERVERS`
(acá va tu servidor de Pterodactyl, por IP de LAN); los contenedores no pueden
iniciar conexiones al propio LXC; y entre sí tampoco (`enable_icc: false`).

Comprobalo desde un contenedor (el primero tiene que fallar, el segundo responder):

```bash
docker exec ca-jugador1 curl -m 5 -sI http://192.168.1.1
docker exec ca-jugador1 curl -m 5 -sI https://example.com
```

Si `iptables` no funciona dentro del LXC, aplicá la misma política en OpenWrt
(zona o VLAN aislada para el LXC: permitir WAN y el `ip:puerto` del servidor de
juego, bloquear el resto de la LAN).

## 4. Proxy y Cloudflare

- **Nginx Proxy Manager**: un Proxy Host por jugador, por ejemplo
  `j1.tudominio.com` → Scheme **https**, IP del LXC, puerto **3101** (3102, 3103
  para los otros), **Websockets Support** activado, certificado SSL de NPM.
  KasmVNC usa un certificado autofirmado en 3001; NPM no lo verifica por defecto.
- **Cloudflare**: nube naranja, modo SSL/TLS **Full**. Los websockets andan por
  defecto. Conviene sumar una política de Cloudflare Access (Zero Trust) por
  host: la autenticación integrada de KasmVNC es, según su documentación, una
  comodidad y no una puerta robusta.
- **No** hagas port-forward de 3101-3103 en el router. La única entrada tiene que
  ser NPM, y en tu firewall solo NPM debería poder llegar a esos puertos.

## 5. Primer uso de cada jugador

1. Abre su URL y entra con su usuario y clave.
2. En el primer arranque aparece **Install Content**: **Quick Install** descarga
   el contenido de la edición freeware de 2008 (verificado por SHA-1). Queda en su
   volumen (`data/jugadorN`) y no se repite.
3. Multiplayer: para tu servidor usá **Direct Connect** con la **IP de LAN** (no la
   pública: depende de que el router haga NAT loopback) o dejá `CA_CONNECT=ip:puerto`
   en el `.env` para que entre directo al abrir el juego.
4. Si cierra el juego, se reabre solo a los pocos segundos. El juego toma la
   resolución del escritorio al abrirse.

## 6. Operación

```bash
docker compose logs -f jugador1          # ver qué pasa
docker compose restart jugador1
docker compose up -d jugador1            # tras cambiar una clave en .env
```

- **Agregar un jugador**: copiá un bloque `jugadorN` en el compose (nombre, puerto
  3104, volumen) y sus variables al `.env`. Para tener menos, borrá el bloque y sus
  variables.
- **Actualizar de versión**: cambiá `CA_VERSION` y `CA_SHA256` juntas en `.env`,
  después `docker compose build --pull jugador1 && docker compose up -d`. Para
  obtener el hash de otra versión, bajá el AppImage de la release y corré
  `sha256sum`; compará con lo que muestra GitHub.
- **Backup**: la carpeta `data/`.

## 7. Qué se verificó y qué no

Verificado en un entorno Ubuntu 24.04 de pruebas:

- El AppImage 1.09 da el SHA-256 del `.env.example` en descargas distintas.
- El cliente arranca como usuario sin privilegios, con la instalación en solo
  lectura, con OpenGL 4.5 por software, y toma la resolución en 1280x720 y 1600x900.
- `ca-launch` con las variables del compose: argumentos, límite de fps, y reinicio
  al cerrar el juego.
- El compose se renderiza y exige las variables obligatorias.
- `lan-isolation.sh`: las reglas cargan, son idempotentes, validan la entrada y se
  quitan limpias (en un namespace de red aislado, **sin tráfico real**).
- Leí los scripts de init de la base: `autostart` se copia una sola vez, no usan
  `sudo`, y Docker interno solo arranca en contenedores privilegiados.

**No verificado** (el primer `docker compose build` y `up` son la prueba real):

- La construcción de la imagen completa y el arranque de KasmVNC: mis registros
  estaban bloqueados.
- `cap_drop: ALL` con las seis capacidades del compose: lo deduje de los scripts de
  init. Si un contenedor no arranca, comentá `cap_drop` y `cap_add`.
- Quick Install: no pude resolver `www.openra.net` desde mi entorno.
- Audio en el navegador, atajos Ctrl+número (los navegadores los reservan para
  cambiar de pestaña), rendimiento en partida, GPU y filtrado real de paquetes.
